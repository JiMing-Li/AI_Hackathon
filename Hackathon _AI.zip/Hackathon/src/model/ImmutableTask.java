package model;

import java.sql.Date;
import java.sql.Time;
import java.util.List;



public class ImmutableTask extends Task{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1429195784455872599L;

	public enum DayOfTheWeek{
		MONDAY, TUESDAY, WEDNESDAY,
		THURSDAY, FIRDAY, SATURDAY,
		SUNDAY
	}
	
	public List<String> dayOftheWeek;
	public Time time;

	public ImmutableTask(String n, int d, List<Date> sd, List<Date> ed, List<String> days, Time t) {
		super(n,d);
		startDate = sd;
		endDate = ed;
		dayOftheWeek = days;
		time = t;
	}
}
