package model;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ScheduleApp implements Serializable {

	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3347340997502206434L;
	
	
	public List<ImmutableTask> itasks;
	public List<MutableTask> mtasks;
	public List<String> types;
	
	public HashMap<String, HashMap<Integer, Integer>> maps;
	List<HashMap<Integer, Integer>> list;
	
	public ScheduleApp()
	{
		itasks = new ArrayList<ImmutableTask> ();
		mtasks = new ArrayList<MutableTask> ();
		types = new ArrayList<String>();
	}
	
	public void read() {
		maps = new HashMap<String, HashMap<Integer, Integer>>();
		for(String s : types) {
			maps.put(s, new HashMap<Integer,Integer> ());
		}
		
		try (BufferedReader br = new BufferedReader(new FileReader("result.txt"))) {
		    String line;
		    while ((line = br.readLine()) != null) {
		     String[] ss = line.split(" ");
		     System.out.print(ss[2]);
		     switch(ss[2]) {
		     case "Study":
		    	 maps.get("Study").put(Integer.parseInt(ss[0]), (int)Double.parseDouble(ss[1].substring(1, ss[1].length()-1)));
		    	 break;
case "Sport":
	maps.get("Sport").put(Integer.parseInt(ss[0]), (int)Double.parseDouble(ss[1].substring(1, ss[1].length()-1)));
	 
		    	 break;

case "Leisure":
	maps.get("Leisure").put(Integer.parseInt(ss[0]), (int)Double.parseDouble(ss[1].substring(1, ss[1].length()-1)));
	 
	 break;

		     }
		    }
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
}
