package model;

import java.sql.Date;
import java.sql.Time;
import java.util.List;

public class MutableTask extends Task{

	public String type;
	public Time EndTime;
	public Date EndDate;
	public Time StartTime;
	
	public MutableTask(String n, String t, int d, Date ed, Time et) {
	super(n,d);
	type = t;
	EndDate = ed;
	EndTime = et;
}
}
