package model;
import java.io.Serializable;
import java.sql.*;
import java.util.List;

public abstract class Task implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2209138473551468798L;

	public String name;
	
	public int duration;
	//public double actualDuration;
	public boolean completion;
	
	
	public List<Date> startDate;
	public List<Time> startTime;
	public List<Date> endDate;
	public List<Time> endTime;
	/*
	public Date deadline;
	*/
	
	
	public Task(String n, int d) {
		name = n;
		duration = d;
		
		
	
	}
	
	
}
