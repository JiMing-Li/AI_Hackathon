package view;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class SchedulePage extends JFrame {

	public Calendar calendar;
	public Todo todo;
	public Attention attention;
	public JButton addTask;
	
	public SchedulePage() {

		super();
		this.setSize(1280, 750);
		this.setResizable(false);
		this.setVisible(true);
		
		// init();
		// InitialDialog initialDialog = new InitialDialog();
		calendar = new Calendar();
		calendar.setBounds(240, 0 , 1040, 600);
		this.add(calendar);
		
		
		
		//
		todo = new Todo();
		todo.setBounds(0,0,240, 720);
		todo.setVisible(true);
		addTask = todo.addTask;
		addTask.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TaskPanel taskPanel = new TaskPanel();
				int result = JOptionPane.showConfirmDialog(null, taskPanel, 
			               "Please Enter New Task", JOptionPane.OK_CANCEL_OPTION);
				if(result == 0) {
					taskPanel.addTask();
					todo.refresh();
					calendar.refresh();
				}
			}
			
		});
		todo.addSchedule.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				SchedulePanel schedulePanel = new SchedulePanel();
				int result = JOptionPane.showConfirmDialog(null, schedulePanel, 
			               "Please Enter New Schedule", JOptionPane.OK_CANCEL_OPTION);
				if(result == 0) {
					schedulePanel.addTask();
					calendar.refresh();
				}
			}
			
		});
		this.add(todo);
		
		attention = new Attention();
		attention.setBounds(240, 600, 1040, 150);
		attention.setting.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TypePanel typePanel = new TypePanel();
				int result = JOptionPane.showConfirmDialog(null, typePanel, 
			               "Change Task Type", JOptionPane.OK_CANCEL_OPTION);
				if(result == 0) {
					//typePanel.addTask();
				}
			}
			
		});
		
		attention.reload.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.print("I CLIKCKED");
				calendar.refresh();
			}
			
		});
		this.add(attention);
		
		
		this.setVisible(true);
		
		//this.add(new Calendar());
	}
	
}