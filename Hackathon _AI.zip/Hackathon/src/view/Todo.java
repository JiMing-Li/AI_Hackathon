package view;

import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Rectangle2D;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import com.sun.javafx.geom.RoundRectangle2D;

import controller.InvalidInputException;
import controller.ScheduleController;
import model.MutableTask;

public class Todo extends JPanel{

	JButton addSchedule;
	JButton addTask;
	
	JPanel aTask;
	JPanel p;
	
	public Todo(){
		super();
		init();

		}
	
	public void init() {
		this.setLayout(null);
		JLabel toDo = new JLabel("TO DO");
		toDo.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 30));
		toDo.setForeground(Color.white);
		toDo.setBounds(50, 50, 100, 50);
 				this.add(toDo);
		addSchedule = new JButton("Add Schedule");
		addSchedule.setBounds(70, 570, 100, 30);
		this.add(addSchedule);
		addTask = new JButton("Add Task");
		addTask.setBounds(70, 620, 100, 30);
		this.add(addTask);
		toBeRefreshed();
		this.setVisible(true);
	}
		
		public void toBeRefreshed() {
			
			this.setVisible(false);
			
			p = new JPanel();
			p.setLayout(new GridLayout(0,1));
			p.setBounds(0, 200, 240, 300);
			
			for(MutableTask t : ScheduleController.getMutableTask()) {
				aTask = new JPanel();
				aTask.add(new JLabel(t.name));
				JButton remove = new JButton("remove");
				remove.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						removeTask(t.name);
						refresh();
					}
					
				});
				JButton complete = new JButton("complete");
				complete.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						
						refresh();
						
						CompletePanel completePanel = new CompletePanel(t.name);
						int result = JOptionPane.showConfirmDialog(null, completePanel, 
					               "Please Enter Parameter for:", JOptionPane.OK_CANCEL_OPTION);
						if(result == 0) {
							completePanel.completeTask();
							refresh();
						}
					}
					
				});
				aTask.add(remove);
				aTask.add(complete);
				p.add(aTask);	
				}
			this.add(p);
			this.setVisible(true);
		}
		
		
		
	public void removeTask(String s) {
		try {
			ScheduleController.removeMutableTask(s);
		} catch (InvalidInputException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	
	public void refresh() {
		this.setVisible(false);
		this.remove(p);
		toBeRefreshed();
	}

public void paintComponent(Graphics g) {
		
	
		super.paintComponent(g);
		Graphics2D graphics2 = (Graphics2D) g;
		Color dark = new Color(79, 110, 102+12);
		Color light = new Color(255, 255, 255, (int)(255*0.35));
		Rectangle2D Rectangle1 = new Rectangle2D.Float( 0, 0,
				240, 720);
		
		Rectangle2D Rectangle2 = new Rectangle2D.Float( 0, 120,
				240, 560);
	
			graphics2.setPaint(dark);
		graphics2.fill(Rectangle1);
		graphics2.draw(Rectangle1);
		
		graphics2.setPaint(light);
		graphics2.fill(Rectangle2);
		graphics2.draw(Rectangle2);
		
	}
}
