package view;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.*;

import controller.InvalidInputException;
import controller.ScheduleController;

public class TypePanel extends JPanel {

public JComboBox typeBox;
public JButton remove;
public JTextField type;
public JButton add;

	public TypePanel() {
		super();
		init();
	}
	
	public void init() {
	this.setLayout(new GridLayout(2,2));	
	
	List<String> list = ScheduleController.getTypes();
	String[] types;
	if(list != null && list.size() > 0) {
	types = new String[list.size()];
	int i = 0;
	for(String s : list) {
		types[i] = list.get(i);
		i++;
	}
	} else {
		types = new String[0];
	}
	typeBox = new JComboBox(types);
	remove = new JButton("remove");
	remove.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			
			removeType();
		}
		
	});
	type = new JTextField(5);
	add = new JButton("add");
	add.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			
			addType();
		}
		
	});
	this.add(typeBox);
	this.add(type);
	this.add(remove);
	this.add(add);
	
	
		
	}
	
	public void addType() {
		String temp = type.getText();
		type.setText("");
	try {
		ScheduleController.addType(temp);
	} catch (InvalidInputException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
	
	public void removeType() {
		try {
			ScheduleController.removeType((String)typeBox.getSelectedItem());
		} catch (InvalidInputException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
}
