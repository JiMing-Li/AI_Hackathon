package view;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.swing.*;

import controller.ScheduleController;
import model.ImmutableTask;
import model.MutableTask;

import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset; 
;




public class Calendar extends JPanel{

	public List<String> days;
	public List<ImmutableTask> itasks;
	public List<MutableTask> mtasks;
	
	GridBagConstraints c;
	
	public static final int row = 35;
	public static final int column = 8;
	
	boolean[][] avail;
	JPanel p;
	
	public Calendar(){
	super();
	defineDay();
	init();

	}
	
	public void defineDay() {
		days = new ArrayList<String>();
		days.add("SUNDAY");
	days.add("MONDAY");
	days.add("TUESDAY");
	days.add("WEDNESDAY");
	days.add("THURSDAY");
	days.add("FRIDAY");
	days.add("SATURDAY");
	
	}
	
	public void init(){
		 avail = new boolean[7][48];
		p = new CalendarPanel(row,column);
		
		this.setLayout(null);
		this.setBackground(Color.WHITE);
		p.setLayout(new GridBagLayout());
		p.setBackground(Color.white);
		c = new GridBagConstraints();
	
 
   
    c.weightx = 0.1;
   c.weighty = 0;
    c.fill = GridBagConstraints.BOTH;
    c.gridx = 0;
 c.gridy = 0;
    
		
    	JLabel label = (new JLabel(" "));
		label.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		p.add(label,c);
		
		label = (new JLabel(" "));
		label.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		c.gridy = 1;
		p.add(label,c);
		
		int j = 12;
		
		for(int i = 0; i < row-1; i++) {
			
			if(j%2== 0) {
				label = new JLabel(j/2 + ":00");
				label.setFont(label.getFont().deriveFont(10.0f));
			}
			else {
				label = new JLabel(j/2 + ":30");
				label.setFont(label.getFont().deriveFont(10.0f));
			}
				j++;
			c.gridy = i + 2;
			label.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		p.add(label,c);
		}
		c.weightx = 1;
		for(int i = 1; i <= column-1; i++) {
			label = new JLabel(days.get(i-1));
			label.setSize(50, label.getHeight());
			c.gridy = 0;
			c.gridx = i;
			label.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		p.add(label,c);
		}
		   
		   LocalDateTime now = LocalDateTime.now();

		for(int i = 1; i <= column-1; i++) {
			 Long longTime = now.atZone(ZoneId.of("-05:00")).toInstant().toEpochMilli();
			 longTime = longTime + ((i-1) * (24*60*60*1000));
	
			  Date dt = new Date(longTime);
			
			label = new JLabel(dt.toString());
			label.setSize(50, label.getHeight());
			c.gridy = 1;
			c.gridwidth = 1;
			c.gridx = i;
			label.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		p.add(label,c);
		}
		
		itasks = ScheduleController.getImmutableTask();
		
		for( ImmutableTask task : itasks) {
			
			label = new JLabel(task.name + task.time + "duration:" + task.duration + "\n" + "size:" + task.dayOftheWeek.size());
			label.setOpaque(true);
			label.setBackground(new Color(13*16+14,14*16+11,15*16+5, 255));
			label.setBorder(BorderFactory.createLineBorder(Color.BLACK));
			label.setFont(label.getFont().deriveFont(10.0f));
			long timeDiff = task.startDate.get(0).getTime() - LocalDate.now().atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli();
		
			//System.out.print((task.time.getTime()/ (60*60*1000)) + "\n");
			int y = (((int)((task.time.getTime() / (60*60*1000)))-11)*2 +2 ) ;
			c.gridy = y;
			System.out.print("y :" + y + "\n");
			int d =  task.duration * 2;
			c.gridheight = d;
			
		for(String s : task.dayOftheWeek) {
			label = new JLabel(task.name + task.time + "duration:" + task.duration + "\n" + "size:" + task.dayOftheWeek.size());
			label.setOpaque(true);
			label.setBackground(new Color(13*16+14,14*16+11,15*16+5, 255));
			label.setBorder(BorderFactory.createLineBorder(Color.BLACK));
			label.setFont(label.getFont().deriveFont(10.0f));
			switch (s) {
			case "MONDAY":
			c.gridx = 2;
			for(int k = 0;k<d;k++) {
					avail[1][y+k] = true;
			}
			p.add(label, c);
			break;
			case "TUESDAY":
				c.gridx = 3;
				for(int k = 0;k<d;k++) {
					avail[2][y+k] = true;
			}
				p.add(label, c);
				break;
			case "WEDNESDAY":
				c.gridx = 4;
				for(int k = 0;k<d;k++) {
					avail[3][y+k] = true;
			}
				p.add(label, c);
				break;
			case "THURSDAY":
				c.gridx = 5;
				for(int k = 0;k<d;k++) {
					avail[4][y+k] = true;
			}
				p.add(label, c);
				break;
			case "FRIDAY":
				c.gridx = 6;
				for(int k = 0;k<d;k++) {
					avail[5][y+k] = true;
			}
				p.add(label, c);
				break;
			case "SATURDAY":
				c.gridx = 7;
				for(int k = 0;k<d;k++) {
					avail[6][y+k] = true;
			}
				p.add(label, c);
				break;
			case "SUNDAY":
				c.gridx = 1;
				for(int k = 0;k<d;k++) {
					avail[0][y+k] = true;
			}
				p.add(label, c);
			break;
			}
		}
		
		
		
	//	p.add(label, c);
		}
		
mtasks = ScheduleController.getMutableTask();
		System.out.print("mtasks:" + mtasks.size() + "\n");
	placeTask();
	
		for(int i = 1; i <= column -1; i++) {
			for(int k = 2; k <= row; k++) {
				label = new JLabel(" ");
				label.setFont(label.getFont().deriveFont(10.0f));
				c.gridx = i;
				c.gridy = k;
				label.setBorder(BorderFactory.createLineBorder(new Color(200,200,200)));
				p.add(label,c);
			}
		}
		
		
		p.setBounds(20,-60,1000,720);
		
		this.add(p);
		this.setVisible(true);
	}
	
	public void placeTask() {
		LocalDateTime now = LocalDateTime.now();
	for( MutableTask task : mtasks) {
		
		int h = now.getHour();
		int d = -1;
		switch(now.getDayOfWeek()) {
		case MONDAY:
			d = 1;
			break;
		case TUESDAY:
			d = 2;
			break;
		case WEDNESDAY:
			d = 3;
			break;
		case THURSDAY:
			d = 4;
			break;
		case FRIDAY:
			d = 5;
			break;
		case SATURDAY:
			d = 6;
			break;
		case SUNDAY:
			d = 0;
			break;
		}
		
		int duration = task.duration;
		int temp = duration;
		boolean skip =false;
	for(int day = d; day < 7; day ++) {
		System.out.println("day" + day + "\n");
		for( int hour = h; hour < 24; hour++) {
			System.out.println("hour:" + hour);
			if(temp<= 0) {
				
				JLabel label;
				label = new JLabel(task.name);
				label.setOpaque(true);
				label.setBackground(new Color(255,255,255,255));
				label.setBorder(BorderFactory.createLineBorder(Color.BLACK));
				label.setFont(label.getFont().deriveFont(10.0f));
				
				c.gridx = day+1;
				c.gridy = hour - duration*2;
				c.gridheight = duration *2;
				p.add(label,c);
				
				for(int x=0;x < duration*2;x++) {
					avail[day][hour-x] = true;
				}
				for(int y = 0; y < 48 ; y++) {
					for(int z = 0; z < 7; z++) {
						System.out.print(avail[z][y] + " ");
					}
					System.out.print( "\n");
				}
					skip = true;
				break;
			}if(!avail[day][hour]) {
			temp--;
			} else {
				temp = duration;
			}
			
		}
		if(skip) {
			skip = false;
			break;
		}
	}
	}	
	}
	public void refresh() {
		this.setVisible(false);
		this.removeAll();
		this.init();
	}
	
}
	 class CalendarPanel extends JPanel{
	
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		int row;
		int column;
		
		public CalendarPanel(int r, int c){
			super();
			row = r;
			column = c;
		}
		
	public void paintComponent(Graphics g) {
		
		
	    super.paintComponent(g);
	    g.setColor(Color.white);
	    g.fillRect(0, 0 , 1040, 600);
	    g.setColor(Color.gray);
	    /*
      for(int i = 2; i < row; i++) {
    	  
    	  g.drawLine(0, 90+i*16, 1040, 90+i*16);
    	 
      }
      for(int j = 1; j < column -1; j++) {
    	  
    	 
    		  g.drawLine(40 +j * 135 , 106, 40 + j * 135, 600);
    	  
    	  
      }*/
     
    
	}
}
