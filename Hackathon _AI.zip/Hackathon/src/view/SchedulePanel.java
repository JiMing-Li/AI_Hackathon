package view;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.sql.Date;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.time.LocalTime;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import org.jdesktop.swingx.JXDatePicker;

import com.github.lgooddatepicker.components.TimePicker;
import com.github.lgooddatepicker.components.TimePickerSettings;

import controller.InvalidInputException;
import controller.ScheduleController;

public class SchedulePanel extends JPanel{

	
	JLabel nameL;
	JLabel durationL;
	JLabel startDateL;
	JLabel endDateL;
	JLabel dayL;
	JLabel startTimeL;
	
	JTextField name;
	JTextField duration;
	JXDatePicker startPicker;
	JXDatePicker endPicker;
	TimePicker timePicker;
	
	List<JRadioButton> buttons;
	
	JPanel inputPanel;
JPanel radioPanel;

public List<String> days;

public void defineDay() {
	days = new ArrayList<String>();
days.add("MONDAY");
days.add("TUESDAY");
days.add("WEDNESDAY");
days.add("THURSDAY");
days.add("FRIDAY");
days.add("SATURDAY");
days.add("SUNDAY");
}
	public SchedulePanel() {
		super();
		defineDay();
		init();
	}
	
	public void init() {
	
	
	
	nameL = new JLabel("Task Name");
	durationL = new JLabel("Duration");
	startDateL = new JLabel("Start Date");
	endDateL = new JLabel("End Date");
	dayL = new JLabel("days");
	startTimeL = new JLabel("start time");
	
	
	name = new JTextField(5);
	duration = new JTextField(5);
	
	
	startPicker = new JXDatePicker();
	startPicker.setDate(Calendar.getInstance().getTime());
	startPicker.setFormats(new SimpleDateFormat("dd.MM.yyyy"));
	
	
	endPicker = new JXDatePicker();
	endPicker.setDate(Calendar.getInstance().getTime());
	endPicker.setFormats(new SimpleDateFormat("dd.MM.yyyy"));
	
	
	TimePickerSettings timeSettings = new TimePickerSettings();
	timeSettings.setColor(TimePickerSettings.TimeArea.TimePickerTextValidTime, Color.black);
	timeSettings.generatePotentialMenuTimes(TimePickerSettings.TimeIncrement.ThirtyMinutes, LocalTime.of(6, 0),
			LocalTime.of(23, 0));
	timeSettings.initialTime = LocalTime.now();
	timePicker = new TimePicker(timeSettings);
	
	
	
	
	inputPanel = new JPanel();
	inputPanel.setLayout(new GridLayout(6,2));
	
	inputPanel.add(nameL);
	inputPanel.add(name);
	inputPanel.add(durationL);
	inputPanel.add(duration);
	inputPanel.add(startDateL);
	inputPanel.add(startPicker);
	inputPanel.add(endDateL);
	inputPanel.add(endPicker);
	inputPanel.add(startTimeL);
	inputPanel.add(timePicker);
	inputPanel.add(dayL);
	
	
	radioPanel = new JPanel();
	radioPanel.setSize(300, 30);
	
	buttons = new ArrayList<JRadioButton>();
	System.out.print(days.size());
	
	for(int i = 0; i < days.size(); i++) {
		JRadioButton radioButton = new JRadioButton(days.get(i));
		buttons.add(radioButton);
		radioPanel.add(radioButton);
	}
	
	inputPanel.add(radioPanel);
	
	this.add(inputPanel, BorderLayout.CENTER);
	
	}
	
	public void addTask() {
		
		List<Date> startdate = new ArrayList<Date>();
				startdate.add(new Date(startPicker.getDate().getTime()));
		List<Date> enddate = new ArrayList<Date>();
		enddate.add(new Date(endPicker.getDate().getTime()));
		List <String> inputs = new ArrayList<String>();
		for(JRadioButton b : buttons){
			if(b.isSelected()) {
				inputs.add(b.getText());
			}
			
		}
		Time time = Time.valueOf(timePicker.getTime());
		System.out.print("here s the time:" + time);
	try {
		ScheduleController.addImmutableTask(name.getText(), Integer.parseInt(duration.getText()), startdate, enddate ,inputs, time);
	} catch (NumberFormatException | InvalidInputException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	}
}
