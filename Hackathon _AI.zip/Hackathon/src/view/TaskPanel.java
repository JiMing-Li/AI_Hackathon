package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.sql.Date;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import org.jdesktop.swingx.JXDatePicker;

import com.github.lgooddatepicker.components.TimePicker;
import com.github.lgooddatepicker.components.TimePickerSettings;

import controller.InvalidInputException;
import controller.ScheduleController;

public class TaskPanel extends JPanel {
	
	JLabel nameL;
	JLabel typeL;
	//JLabel durationL;
	JLabel endDateL;
	JLabel endTimeL;
	
	JTextField name;
	JComboBox type;
	//JTextField duration;	
	JXDatePicker endPicker;
	TimePicker timePicker;
	
	
	JPanel inputPanel;


public List<String> days;

public void defineDay() {
	days = new ArrayList<String>();
days.add("MONDAY");
days.add("TUESDAY");
days.add("WEDNESDAY");
days.add("THURSDAY");
days.add("FRIDAY");
days.add("SATURDAY");
days.add("SUNDAY");
}
	public TaskPanel() {
		super();
		defineDay();
		init();
	}
	
	public void init() {
	
	
	
	nameL = new JLabel("Task Name");	
	typeL = new JLabel("Task Type");
	//durationL = new JLabel("Duration");
	endDateL = new JLabel("End Date");
	endTimeL = new JLabel("End Time");
	
	
	name = new JTextField(5);
	//duration = new JTextField(5);
	List<String> list = ScheduleController.getTypes();
	String[] types = new String[list.size()];
	int i = 0;
	if(list.size() > 0) {
	for(String s : list) {
		types[i] = list.get(i);
		i++;
	}
	}
	type = new JComboBox(types);
	
	endPicker = new JXDatePicker();
	endPicker.setDate(Calendar.getInstance().getTime());
	endPicker.setFormats(new SimpleDateFormat("dd.MM.yyyy"));
	
	
	TimePickerSettings timeSettings = new TimePickerSettings();
	timeSettings.setColor(TimePickerSettings.TimeArea.TimePickerTextValidTime, Color.black);
	timeSettings.generatePotentialMenuTimes(TimePickerSettings.TimeIncrement.ThirtyMinutes, LocalTime.of(6, 0),
			LocalTime.of(23, 0));
	timeSettings.initialTime = LocalTime.now();
	timePicker = new TimePicker(timeSettings);
	
	
	
	
	
	inputPanel = new JPanel();
	inputPanel.setLayout(new GridLayout(5,2));
	
	inputPanel.add(nameL);
	inputPanel.add(name);
	inputPanel.add(typeL);
	inputPanel.add(type);
	//inputPanel.add(durationL);
	//inputPanel.add(duration);
	inputPanel.add(endDateL);
	inputPanel.add(endPicker);
	inputPanel.add(endTimeL);
	inputPanel.add(timePicker);

	

	
	
	
	
	this.add(inputPanel, BorderLayout.CENTER);
	
	}
	
	public void addTask() {
		
		
		
		Date enddate = new Date(endPicker.getDate().getTime());
		
		
		Time time = Time.valueOf(timePicker.getTime());
		System.out.print("here s the time:" + time);
	try {
		ScheduleController.addMutableTask(name.getText(),(String)type.getSelectedItem(), enddate, time);
	} catch (NumberFormatException | InvalidInputException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	}
}
