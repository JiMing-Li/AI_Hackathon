package view;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Rectangle2D;
import java.time.LocalDateTime;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import application.ScheduleApplication;
import model.ScheduleApp;

public class Attention extends JPanel {

	public JButton setting;
	public JButton prev;
	public JButton reload;
	public JButton next;
	
	public JButton load;
	
	public JLabel l;
	public Attention(){
		super();
		init();

		}
	
	public void init() {
		
		this.setLayout(null);
		load = new JButton("Check");
		load.setBounds(490, 600, 100, 30);
		setting = new JButton("setting");
		setting.setBounds(240, 600, 100, 30);
		prev = new JButton("<");
		prev.setBounds(340, 600, 50, 30);
		reload = new JButton("R");
		reload.setBounds(390, 600, 50, 30);
		next = new JButton(">");
		next.setBounds(440, 600, 50, 30);
		l = new JLabel(" ");
		l.setBounds(500 ,650, 600, 50);
		load.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
					load();
			}
			
		});
		this.add(load);
		this.add(setting);
		this.add(prev);
		this.add(reload);
		this.add(next);
		this.add(l);
	}
	
	public void load() {
		ScheduleApp s = ScheduleApplication.getScheduleApp();
		LocalDateTime now = LocalDateTime.now();
		l.setText(( Double.toString(((double)(s.maps.get("Study").get(now.getHour()))    /(3600.0) ))) + "hour to perform study right now.");
	}
	
	public void paintComponent(Graphics g) {
		
		
		super.paintComponent(g);
		Graphics2D graphics2 = (Graphics2D) g;
		Color dark = new Color(145, 174, 16*11+9);
		Color light = new Color(255, 255, 255, (int)(255*0.35));
		Rectangle2D Rectangle1 = new Rectangle2D.Float( 240, 600,
				1040, 120);
		Rectangle2D Rectangle2 = new Rectangle2D.Float( 240, 630,
				1040, 50);
		
			graphics2.setPaint(dark);
		graphics2.fill(Rectangle1);
		graphics2.draw(Rectangle1);
		graphics2.setPaint(light);
		graphics2.fill(Rectangle2);
		graphics2.draw(Rectangle2);
		
	}

}
