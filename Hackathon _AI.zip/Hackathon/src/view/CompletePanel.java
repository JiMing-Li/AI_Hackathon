package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.sql.Time;
import java.time.LocalTime;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.jdesktop.swingx.JXDatePicker;

import com.github.lgooddatepicker.components.TimePicker;
import com.github.lgooddatepicker.components.TimePickerSettings;

import controller.InvalidInputException;
import controller.ScheduleController;

public class CompletePanel extends JPanel{

	String string;
	JLabel nameL;
	JLabel durationL;
	JLabel startTimeL;
	JTextField duration;
	TimePicker timePicker;
	public CompletePanel(String s) {
		super();
		string = s;
		init(s);
		
	}
	
	public void init(String s) {
		nameL = new JLabel("Task: " + s );
		durationL = new JLabel("duration");
		startTimeL = new JLabel("start Time");
		duration = new JTextField(5);
		
		TimePickerSettings timeSettings = new TimePickerSettings();
		timeSettings.setColor(TimePickerSettings.TimeArea.TimePickerTextValidTime, Color.black);
		timeSettings.generatePotentialMenuTimes(TimePickerSettings.TimeIncrement.ThirtyMinutes, LocalTime.of(6, 0),
				LocalTime.of(23, 0));
		timeSettings.initialTime = LocalTime.now();
		timePicker = new TimePicker(timeSettings);
		
		
		//this.setLayout();
		JPanel p  = new JPanel();
				p.setLayout(new GridLayout(2,2));
				p.add(durationL);
				p.add(duration);
				p.add(startTimeL);
				p.add(timePicker);
				this.setLayout(new BorderLayout());
				this.add(nameL, BorderLayout.PAGE_START);
				this.add(p, BorderLayout.CENTER);
				this.setVisible(true);
	}
	
	
	public void completeTask() {
		Time time = Time.valueOf(timePicker.getTime());
	System.out.print(string);
		try {
			ScheduleController.completeMutableTask(string,Integer.parseInt(duration.getText()),time);
		} catch (InvalidInputException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
