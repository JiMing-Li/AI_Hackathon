package controller;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;

import application.ScheduleApplication;
import model.ImmutableTask;
import model.MutableTask;
import model.ScheduleApp;

public class ScheduleController {

	public static void addImmutableTask(String name,int duration, List<Date> startDate,List<Date> endDate, List<String> dayOfTheWeek, Time time) 
		throws InvalidInputException {
			if (name == "" || duration <= 0 || dayOfTheWeek.size() <=0) {
				throw new InvalidInputException("Invalid input, negative numbers not accepted");
			}
			
			ScheduleApp s = ScheduleApplication.getScheduleApp();
			
		List<ImmutableTask> itasks = s.itasks;
		
		System.out.print("task size is: " + s.itasks.size());
		//System.out.print(s.itasks.get(0));
		ImmutableTask task = new ImmutableTask(name, duration,startDate, endDate, dayOfTheWeek, time);
		itasks.add(task);
		try {
			ScheduleApplication.save();
		} catch (RuntimeException e) {
			throw new InvalidInputException(e.getMessage());
		}
	}
	
	public static void addMutableTask(String name,String type, Date endDate, Time time) 
			throws InvalidInputException {
				if (name == "" ) {
					throw new InvalidInputException("Invalid input");
				}
				
				ScheduleApp s = ScheduleApplication.getScheduleApp();
				
			List<MutableTask> mtasks = s.mtasks;
			int duration = 1;
			
			System.out.print("task size is: " + s.itasks.size());
			//System.out.print(s.itasks.get(0));
			MutableTask task = new MutableTask(name,type, duration, endDate, time);
			
			
			
			
			mtasks.add(task);
			try {
				ScheduleApplication.save();
			} catch (RuntimeException e) {
				throw new InvalidInputException(e.getMessage());
			}
		}
	
	public static void removeMutableTask(String task) throws InvalidInputException {
		if (task == "" ) {
			throw new InvalidInputException("Invalid input");
			
		}
		ScheduleApp s = ScheduleApplication.getScheduleApp();
		MutableTask currentTask = null;
		for(MutableTask t : s.mtasks) {
			if(task == t.name) {
				currentTask = t;
				break;
			}
		}
		if(currentTask != null) {
			s.mtasks.remove(currentTask);
			}
		
		try {
			ScheduleApplication.save();
		} catch (RuntimeException e) {
			throw new InvalidInputException(e.getMessage());
		}
		
	}
	
	public static void completeMutableTask(String task, int duration, Time time) throws InvalidInputException {
		if (task == "" ) {
			throw new InvalidInputException("Invalid input");
			
		}
		ScheduleApp s = ScheduleApplication.getScheduleApp();
		MutableTask currentTask = null;
		for(MutableTask t : s.mtasks) {
			if(task == t.name) {
				currentTask = t;
				break;
			}
		}
		if(currentTask != null) {
			s.mtasks.remove(currentTask);
			currentTask.duration = duration;
			currentTask.StartTime = time;
			writeTasktoFile(currentTask);
			}
		

		
		try {
			ScheduleApplication.save();
		} catch (RuntimeException e) {
			throw new InvalidInputException(e.getMessage());
		}
		
	}
	
	public static void writeTasktoFile(MutableTask task) {
		//write your code here
		String type = task.type;
		String hour = Integer.toString(task.StartTime.getHours());
		System.out.println(hour);
		String duration = Integer.toString(task.duration*60*60);
		
		FileWriter pw;
		try {
			pw = new FileWriter("toddurtype.csv",true);
			pw.append(System.getProperty( "line.separator" ));
			
            pw.append(hour);
            pw.append(",");
            pw.append(duration);
            pw.append(",");
            pw.append(type);
          
        
            pw.flush();
            pw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
    
	}
	
	public static List<ImmutableTask> getImmutableTask(){
		ScheduleApp s = ScheduleApplication.getScheduleApp();
		List<ImmutableTask> itasks = s.itasks;
		return itasks;
	}
	
	public static List<MutableTask> getMutableTask(){
		ScheduleApp s = ScheduleApplication.getScheduleApp();
		List<MutableTask> mtasks = s.mtasks;
		return mtasks;
	}
	
	public static List<String> getTypes(){
		ScheduleApp s = ScheduleApplication.getScheduleApp();
		List<String> types = s.types;
		return types;
	}
	
	public static void addType(String type)throws InvalidInputException {
		if (type == "") {
			throw new InvalidInputException("Invalid input");
		}
		ScheduleApp s = ScheduleApplication.getScheduleApp();
		if(s.types == null || s.types.size() <=0) {
			s.types = new ArrayList<String>();
		}
		s.types.add(type);
		try {
			ScheduleApplication.save();
		} catch (RuntimeException e) {
			throw new InvalidInputException(e.getMessage());
		}
		
	}
	public static void removeType(String type) throws InvalidInputException{
		if (type == "") {
			throw new InvalidInputException("Invalid input");
		}
		ScheduleApp s = ScheduleApplication.getScheduleApp();
		s.types.remove(type);
		try {
			ScheduleApplication.save();
		} catch (RuntimeException e) {
			throw new InvalidInputException(e.getMessage());
		}
		
		
	}
}
	
	/*
	public static void createTable(int number, int x, int y, int width, int length, int numberOfSeats)
			throws InvalidInputException {
		if (x < 0 || y < 0 || width <= 0 || length <= 0 || numberOfSeats <= 0) {
			throw new InvalidInputException("Invalid input, negative numbers not accepted");
		}
		RestoApp r = RestoAppApplication.getRestoApp();
		r.reinitialize();
		List<Table> currentTables = r.getCurrentTables();

		for (Table currentTable : currentTables) {
			Boolean overlap = currentTable.doesOverlap(x, y, width, length);
			if (overlap == true) {
				throw new InvalidInputException(
						"Error: the table you are trying to create overlaps with a previously existing one");
			}
			if (currentTable.getNumber() == number) {
				System.out
						.println("currentTable number is: " + currentTable.getNumber() + "and input number: " + number);
				throw new InvalidInputException("Table number already exists");
			}
		}

		Table table;
		String error = "";
		// try {
		System.out.print(number);
		System.out.print(x);
		System.out.print(y);
		System.out.print(width);
		System.out.print(length);
		System.out.println("\n");
		table = new Table(number, x, y, width, length, r);

		r.addCurrentTable(table);
		if (number == 201115)
		{
			r.setTakeOutTable(table);
			System.out.println("check: table with special ID 201115 has been set as takeout table");
		}
		for (int i = 1; i <= numberOfSeats; i++) {
			Seat seat = table.addSeat();
			table.addCurrentSeat(seat);
		}
		try {
			RestoAppApplication.save();
		} catch (RuntimeException e) {
			throw new InvalidInputException(e.getMessage());
		}

	}*/
	

