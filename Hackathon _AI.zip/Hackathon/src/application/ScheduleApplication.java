package application;
import model.ScheduleApp;
import persistence.PersistenceObjectStream;
import view.SchedulePage;;

public class ScheduleApplication {
	
	private static ScheduleApp scheduleApp;
	private static String filename = "schedule.sch";
	

	
		
		public static void main(String[] args) {
			// start UI
	        java.awt.EventQueue.invokeLater(new Runnable() {
	            public void run() {
	                new SchedulePage().setVisible(true);
	               
	            }
	        });
	}
	

	public static ScheduleApp getScheduleApp() {
		if (scheduleApp == null) {
			// load model
			scheduleApp = load();
		}
 		return scheduleApp;
	}
	
	public static void save() {
		// scheduleApp.reinitialize();
		PersistenceObjectStream.serialize(scheduleApp);
	}
	
	public static ScheduleApp load() {
		PersistenceObjectStream.setFilename(filename);
		scheduleApp = (ScheduleApp) PersistenceObjectStream.deserialize();
		// model cannot be loaded - create empty BTMS
		if (scheduleApp == null) {
			scheduleApp = new ScheduleApp();
		}
		else {
		//	scheduleApp.reinitialize();
		}
		scheduleApp.read();
		
		
		return scheduleApp;
	}
	
	public static void setFilename(String newFilename) {
		filename = newFilename;
	}

}
