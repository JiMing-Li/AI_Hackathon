import datetime 

#declare variables 
int currentTime = datetime.datetime.now()
int duration 
int dueDate
int timeAvailable = dueDate - currentTime
int points = 0 
int startTime
str name 

#calculate frequency of tasks 
#is a certain task frequently completed at the same time 
 if ()


#assign points  
points = duration * (1/timeAvailable)
